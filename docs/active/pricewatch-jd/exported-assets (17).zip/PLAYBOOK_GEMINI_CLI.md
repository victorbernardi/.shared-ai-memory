# PLAYBOOK GEMINI CLI / ANTIGRAVITY
# PROJETO: Pesquisa de Preços John Deere - Mercado Paralelo
# Concessionária Inova
# Data: 06/05/2026

================================================================================
1. ESTRUTURA DE ARQUIVOS DO PROJETO
================================================================================

DIRETÓRIO RAIZ: ~/projetos/pesquisa-precos-john-deere/

projeto/
├── README.md                          ← Este documento (leia primeiro)
├── 00-SETUP/
│   └── instalar_dependencias.sh       ← Script de instalação inicial
├── 01-MAPEAMENTO/
│   ├── mapear_concorrentes.py         ← Identifica concorrentes por região
│   └── concorrentes_base.csv          ← Base de 12 concorrentes nacionais
├── 02-PESQUISA/
│   ├── gerar_prompts_pesquisa.py    ← Cria prompts para o Gemini CLI
│   ├── executar_pesquisa_loop.sh    ← Executa pesquisa em lote via Gemini
│   └── coletar_resultados.py        ← Processa JSON de retorno do Gemini
├── 03-BANCO/
│   ├── template_dados_banco.csv     ← Template para exportar do BD Inova
│   └── script_substituicao.py       ← Substitui valores reais no Excel
├── 04-CONSOLIDACAO/
│   ├── consolidar_planilha.py     ← Gera Excel final comparativo
│   └── gerar_relatorio_gerencial.py ← Gera resumo executivo
└── output/
    ├── pesquisa_precos_base.xlsx    ← Planilha base (c/ valores estimados)
    ├── pesquisa_precos_final.xlsx   ← Planilha c/ dados reais do banco
    └── mapeamento_concorrentes.xlsx   ← Relatório de concorrentes

================================================================================
2. FLUXO DE TRABALHO (WORKFLOW)
================================================================================

ETAPA 1: MAPEAMENTO DE CONCORRENTES
------------------------------------
Objetivo: Identificar quem são os concorrentes do mercado paralelo

Comando:
    python 01-MAPEAMENTO/mapear_concorrentes.py

Entrada:
    - Coordenadas das lojas Inova (hardcoded no script)
    - Lista base de concorrentes (concorrentes_base.csv)

Saída:
    - output/mapeamento_concorrentes.xlsx
    - Lista de concorrentes próximos a cada loja Inova (até 300km)

Pontos de atenção:
    - Atualizar coordenadas GPS das lojas Inova se houver mudança
    - Adicionar novos concorrentes descobertos ao CSV
    - Se usar Google Maps API, configurar chave em GOOGLE_MAPS_API_KEY

ETAPA 2: PESQUISA DE PREÇOS VIA GEMINI CLI
------------------------------------------
Objetivo: Obter preços do mercado paralelo para cada peça

Passo 2A - Gerar prompts:
    python 02-PESQUISA/gerar_prompts_pesquisa.py --peca RE509672

    Saída: prompt otimizado para o Gemini CLI

Passo 2B - Executar pesquisa (manual ou loop):
    gemini query "$(python 02-PESQUISA/gerar_prompts_pesquisa.py RE509672)"

    Ou para múltiplas peças:
    bash 02-PESQUISA/executar_pesquisa_loop.sh lista_pecas.txt

Passo 2C - Coletar resultados:
    python 02-PESQUISA/coletar_resultados.py --input resultados_gemini.json

    Saída: arquivo JSON estruturado pronto para consolidação

Pontos de atenção:
    - Gemini CLI pode ter rate limit: aguardar 5-10s entre consultas
    - Sempre salvar o JSON retornado pelo Gemini em arquivo
    - Verificar se o preço é da peça EXATA ou similar/compatível
    - Registrar a URL exata de onde o preço foi obtido
    - Data da pesquisa deve ser capturada automaticamente

ETAPA 3: INTEGRAÇÃO COM BANCO DE DADOS INOVA
--------------------------------------------
Objetivo: Inserir valores reais (oficial e Inova) na planilha

Passo 3A - Exportar do banco:
    Gerar CSV com: numero_peca | valor_oficial_john_deere | valor_praticado_inova
    Salvar como: 03-BANCO/dados_reais_banco.csv

Passo 3B - Executar substituição:
    python 03-BANCO/script_substituicao.py         --banco 03-BANCO/dados_reais_banco.csv         --pesquisa output/pesquisa_precos_base.xlsx         --saida output/pesquisa_precos_final.xlsx

Pontos de atenção:
    - O CSV deve usar ponto-e-vírgula (;) ou vírgula (,) como separador
    - Valores podem conter R$, pontos e vírgulas - o script limpa automaticamente
    - Peças não encontradas no CSV mantêm os valores estimados originais
    - SEMPRE fazer backup do Excel antes de executar

ETAPA 4: CONSOLIDAÇÃO E RELATÓRIO
---------------------------------
Objetivo: Gerar planilha final e relatório para o gerente

Comando:
    python 04-CONSOLIDACAO/consolidar_planilha.py         --input output/pesquisa_precos_final.xlsx

Saída:
    - output/pesquisa_precos_final.xlsx (atualizado c/ formatação)
    - output/relatorio_gerencial.pdf ou .docx (se gerado)

================================================================================
3. NOMENCLATURA DE ARQUIVOS (REGRA OBRIGATÓRIA)
================================================================================

Para evitar conflitos de versão, NUNCA use nomes genéricos como:
    ❌ script.py
    ❌ script1.py, script2.py
    ❌ teste.py, final.py, novo.py

Sempre use:
    ✅ [NUMERO]-[MODULO]/[NOME_DESCRITIVO].py
    ✅ Data no nome se for backup: pesquisa_2026-05-06_v1.xlsx
    ✅ Sufixo de versão: _v1, _v2, _final

Exemplos corretos:
    01-MAPEAMENTO/mapear_concorrentes_v1.py
    02-PESQUISA/gerar_prompts_pesquisa_v1.py
    output/pesquisa_precos_2026-05-06_v1.xlsx

================================================================================
4. DEPENDÊNCIAS E INSTALAÇÃO
================================================================================

Requisitos:
    Python 3.9+
    Gemini CLI ou Antigravity instalado
    pip instalado

Instalar dependências:
    pip install pandas openpyxl geopy requests

Verificar instalação:
    python --version
    gemini --version  # ou antigravity --version

================================================================================
5. CONFIGURAÇÃO DO GEMINI CLI
================================================================================

Variáveis de ambiente (adicionar ao ~/.bashrc ou ~/.zshrc):
    export GEMINI_API_KEY="sua_chave_aqui"
    export GEMINI_MODEL="gemini-2.5-pro"  # ou o modelo disponível

Verificar conexão:
    gemini query "teste de conexão"

Rate limiting:
    - Máximo de 10 consultas por minuto (ajustar conforme plano)
    - Aguardar 5-10 segundos entre pesquisas de peças
    - Em caso de erro 429, aguardar 60 segundos e retomar

================================================================================
6. LISTA DE CONCORRENTES PARA PESQUISA (PRIORIDADE)
================================================================================

ORDEM DE PESQUISA (do mais relevante ao menos):

1. EG Peças           (egindustriadepecas.com.br)     ← Mais direto
2. TBL Agro Peças     (loja.tblagropecas.com.br)       ← Preços online
3. Super Tractor      (supertractor.com.br)            ← Grande porte
4. Ditrac             (ditrac.com.br)                  ← Centro-Oeste
5. Rech Peças         (rech.com)                       ← Multi-regional
6. Canaparts          (canaparts.com.br)               ← John Deere específico
7. FridayParts        (br.fridayparts.com)             ← Importados
8. Magazine Luiza     (magazineluiza.com.br)           ← Marketplace
9. Mercado Livre      (mercadolivre.com.br)            ← Anúncios
10. MF Rural          (mfrural.com.br)                 ← Classificados
11. Agrofy            (agrofy.com.br)                  ← Marketplace agrícola
12. Google Shopping   (google.com/shopping)            ← Busca geral

================================================================================
7. FORMATO ESPERADO DO RETORNO DO GEMINI
================================================================================

O Gemini CLI deve retornar JSON no seguinte formato:

{
  "numero_peca": "RE509672",
  "data_pesquisa": "2026-05-06",
  "resultados": [
    {
      "fonte": "EG Peças",
      "url": "https://egindustriadepecas.com.br/peca/RE509672",
      "preco": 120.00,
      "moeda": "BRL",
      "disponibilidade": "em_estoque",
      "observacao": "preço à vista, peça compatível (Donaldson)"
    }
  ],
  "menor_preco": 120.00,
  "maior_preco": 190.00,
  "media_preco": 155.00,
  "total_fontes": 3
}

Campos obrigatórios:
    - numero_peca
    - resultados (array, pode estar vazio)
    - data_pesquisa

Campos opcionais mas recomendados:
    - menor_preco, maior_preco, media_preco
    - observacao (se é peça original, compatível, importada)

================================================================================
8. PONTOS DE ATENÇÃO CRÍTICOS
================================================================================

🔴 NUNCA fazer:
    - Pesquisar mais de 10 peças sem pausa (rate limit)
    - Ignorar a observação sobre peça ser "compatível" vs "original"
    - Salvar sobre o arquivo original sem backup
    - Usar nomes genéricos de arquivo
    - Deixar de registrar a URL fonte (impossibilita auditoria)

🟡 SEMPRE verificar:
    - Se o número da peça pesquisada é EXATO ou similar
    - Se o preço inclui ou não impostos (ICMS, IPI)
    - Se o preço é à vista ou parcelado
    - Se há frete incluso ou não
    - Disponibilidade de estoque

🟢 BOAS PRÁTICAS:
    - Fazer backup antes de cada execução
    - Versionar arquivos com data
    - Documentar peças onde preço não foi encontrado
    - Revisar manualmente resultados suspeitos (muito barato)
    - Validar URLs antes de incluir na planilha

================================================================================
9. TROUBLESHOOTING
================================================================================

Problema: Gemini CLI retorna erro 429 (Too Many Requests)
Solução: Aguardar 60 segundos. Reduzir frequência para 1 consulta a cada 10s.

Problema: Preço não encontrado no site do concorrente
Solução: Marcar como "Preço sob orçamento". Tentar contato via WhatsApp do site.

Problema: Script de substituição não encontra coluna no CSV
Solução: Verificar se o CSV usa ; ou , como separador. Normalizar nomes das colunas.

Problema: Excel corrompido após substituição
Solução: Restaurar backup. Verificar se valores numéricos não contêm texto.

Problema: Concorrente mudou o layout do site
Solução: Atualizar o prompt do Gemini para refletir novo layout. Testar manualmente.

================================================================================
10. CHECKLIST PRÉ-REUNIÃO COM GERENTE
================================================================================

[ ] Banco de dados exportado em CSV
[ ] Script de substituição executado sem erros
[ ] Planilha final abre corretamente no Excel
[ ] Colunas D e E contêm valores REAIS (não estimados)
[ ] Cores de destaque estão corretas (verde/vermelho/amarelo)
[ ] Aba Resumo tem números atualizados
[ ] URLs de fonte são válidas (testar 3 aleatórias)
[ ] Pelo menos 50% das peças têm preço de mercado paralelo
[ ] Backup da planilha final salvo em local separado

================================================================================
CONTATO E SUPORTE
================================================================================

Em caso de dúvidas sobre o projeto:
1. Consultar este README
2. Verificar INSTRUCOES_SUBSTITUICAO.md
3. Revisar comentários nos scripts Python

================================================================================
