
import pandas as pd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils.dataframe import dataframe_to_rows

# Dados das 56 peças
pecas = [
    {"numero_peca": "RE509672", "descricao": "Filtro Óleo Motor John Deere (Colhedoras STS/Tratores)", "categoria": "Filtro", "valor_oficial_estimado": 185.00, "valor_inova_estimado": 166.50, "menor_preco_paralelo": 120.00, "fonte_menor": "Agrotrator / Acamargo", "url_fonte": "https://www.agrotrator.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "RE504836", "descricao": "Filtro Óleo Motor Donaldson Compatível John Deere", "categoria": "Filtro", "valor_oficial_estimado": 195.00, "valor_inova_estimado": 175.50, "menor_preco_paralelo": 147.25, "fonte_menor": "De Bona Peças", "url_fonte": "https://www.debonapecas.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "RE522868", "descricao": "Filtro Combustível John Deere (Tratores 6125E/6125J)", "categoria": "Filtro", "valor_oficial_estimado": 145.00, "valor_inova_estimado": 130.50, "menor_preco_paralelo": None, "fonte_menor": "FridayParts (importado)", "url_fonte": "https://br.fridayparts.com", "data_pesquisa": "06/05/2026", "status": "Preço sob consulta"},
    {"numero_peca": "AH212102", "descricao": "Correia/Tensor John Deere (componente sistema)", "categoria": "Correia", "valor_oficial_estimado": 420.00, "valor_inova_estimado": 378.00, "menor_preco_paralelo": None, "fonte_menor": "Pavoni Trator Peças", "url_fonte": "https://www.pavoni.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob consulta"},
    {"numero_peca": "RE27284", "descricao": "Rolamento John Deere (transmissão/eixo)", "categoria": "Rolamento", "valor_oficial_estimado": 850.00, "valor_inova_estimado": 765.00, "menor_preco_paralelo": 712.67, "fonte_menor": "Magazine Luiza (Fag compatível)", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "RE506352", "descricao": "Peça John Deere - Colheitadeira", "categoria": "Colheitadeira", "valor_oficial_estimado": 320.00, "valor_inova_estimado": 288.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças (catálogo)", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE506424", "descricao": "Peça John Deere - Colheitadeira", "categoria": "Colheitadeira", "valor_oficial_estimado": 280.00, "valor_inova_estimado": 252.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças (catálogo)", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE519696", "descricao": "Peça John Deere - Colheitadeira/Pulverizador/Trator", "categoria": "Multi", "valor_oficial_estimado": 450.00, "valor_inova_estimado": 405.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças (catálogo)", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE522794", "descricao": "Peça John Deere - Colheitadeira/Trator", "categoria": "Multi", "valor_oficial_estimado": 380.00, "valor_inova_estimado": 342.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças (catálogo)", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "H231930", "descricao": "Chapa Deslizante UHMW John Deere", "categoria": "Desgaste", "valor_oficial_estimado": 65.00, "valor_inova_estimado": 58.50, "menor_preco_paralelo": 30.00, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "AH94450", "descricao": "Polia Tensora Elevador Grãos STS John Deere", "categoria": "Polia", "valor_oficial_estimado": 550.00, "valor_inova_estimado": 495.00, "menor_preco_paralelo": 408.28, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "AH202008", "descricao": "Polia Elevador Grãos STS John Deere", "categoria": "Polia", "valor_oficial_estimado": 1400.00, "valor_inova_estimado": 1260.00, "menor_preco_paralelo": 1050.00, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "CQ58874", "descricao": "Correia John Deere Original Continental", "categoria": "Correia", "valor_oficial_estimado": 180.00, "valor_inova_estimado": 162.00, "menor_preco_paralelo": 151.91, "fonte_menor": "Magazine Luiza", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "R245222", "descricao": "Correia John Deere", "categoria": "Correia", "valor_oficial_estimado": 170.00, "valor_inova_estimado": 153.00, "menor_preco_paralelo": None, "fonte_menor": "Magazine Luiza", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Preço variável"},
    {"numero_peca": "L214835", "descricao": "Correia Trapezoidal John Deere Original Continental", "categoria": "Correia", "valor_oficial_estimado": 300.00, "valor_inova_estimado": 270.00, "menor_preco_paralelo": 269.90, "fonte_menor": "Magazine Luiza", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "AH232714", "descricao": "Tensor Correia John Deere", "categoria": "Tensor", "valor_oficial_estimado": 750.00, "valor_inova_estimado": 675.00, "menor_preco_paralelo": 529.17, "fonte_menor": "Magazine Luiza", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "M158130", "descricao": "Correia John Deere", "categoria": "Correia", "valor_oficial_estimado": 160.00, "valor_inova_estimado": 144.00, "menor_preco_paralelo": None, "fonte_menor": "Magazine Luiza", "url_fonte": "https://www.magazineluiza.com.br", "data_pesquisa": "06/05/2026", "status": "Preço variável"},
    {"numero_peca": "AL118036", "descricao": "Filtro Hidráulico John Deere (6400/6410/6420)", "categoria": "Filtro", "valor_oficial_estimado": 280.00, "valor_inova_estimado": 252.00, "menor_preco_paralelo": 194.79, "fonte_menor": "FridayParts", "url_fonte": "https://br.fridayparts.com", "data_pesquisa": "06/05/2026", "status": "Pesquisado"},
    {"numero_peca": "RE34958", "descricao": "Filtro Hidráulico John Deere", "categoria": "Filtro", "valor_oficial_estimado": 250.00, "valor_inova_estimado": 225.00, "menor_preco_paralelo": None, "fonte_menor": "FridayParts", "url_fonte": "https://br.fridayparts.com", "data_pesquisa": "06/05/2026", "status": "Preço sob consulta"},
    {"numero_peca": "AL233526", "descricao": "Filtro Hidráulico John Deere", "categoria": "Filtro", "valor_oficial_estimado": 260.00, "valor_inova_estimado": 234.00, "menor_preco_paralelo": None, "fonte_menor": "FridayParts", "url_fonte": "https://br.fridayparts.com", "data_pesquisa": "06/05/2026", "status": "Preço sob consulta"},
    {"numero_peca": "RE174130", "descricao": "Filtro Ar John Deere", "categoria": "Filtro", "valor_oficial_estimado": 220.00, "valor_inova_estimado": 198.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac / EG Peças", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AR95758", "descricao": "Filtro Ar Secundário John Deere", "categoria": "Filtro", "valor_oficial_estimado": 190.00, "valor_inova_estimado": 171.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac / EG Peças", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE57394", "descricao": "Filtro Combustível John Deere", "categoria": "Filtro", "valor_oficial_estimado": 130.00, "valor_inova_estimado": 117.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE60021", "descricao": "Filtro Óleo Hidráulico John Deere", "categoria": "Filtro", "valor_oficial_estimado": 175.00, "valor_inova_estimado": 157.50, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AH128449", "descricao": "Correia Ventilador John Deere", "categoria": "Correia", "valor_oficial_estimado": 210.00, "valor_inova_estimado": 189.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AH141537", "descricao": "Correia John Deere", "categoria": "Correia", "valor_oficial_estimado": 195.00, "valor_inova_estimado": 175.50, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE210857", "descricao": "Rolamento John Deere (roda dianteira)", "categoria": "Rolamento", "valor_oficial_estimado": 320.00, "valor_inova_estimado": 288.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE210858", "descricao": "Rolamento John Deere (roda traseira)", "categoria": "Rolamento", "valor_oficial_estimado": 480.00, "valor_inova_estimado": 432.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE211277", "descricao": "Rolamento John Deere (caixa de câmbio)", "categoria": "Rolamento", "valor_oficial_estimado": 650.00, "valor_inova_estimado": 585.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE27348", "descricao": "Rolamento John Deere (diferencial)", "categoria": "Rolamento", "valor_oficial_estimado": 1100.00, "valor_inova_estimado": 990.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "SU262237", "descricao": "Junta Homocinética John Deere", "categoria": "Transmissão", "valor_oficial_estimado": 750.00, "valor_inova_estimado": 675.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "SU262238", "descricao": "Junta Homocinética John Deere", "categoria": "Transmissão", "valor_oficial_estimado": 820.00, "valor_inova_estimado": 738.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE500734", "descricao": "Pastilha Freio John Deere", "categoria": "Freio", "valor_oficial_estimado": 290.00, "valor_inova_estimado": 261.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE500735", "descricao": "Pastilha Freio John Deere", "categoria": "Freio", "valor_oficial_estimado": 310.00, "valor_inova_estimado": 279.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "R271794", "descricao": "Disco Freio John Deere", "categoria": "Freio", "valor_oficial_estimado": 580.00, "valor_inova_estimado": 522.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE181915", "descricao": "Vedação Retentor John Deere", "categoria": "Vedação", "valor_oficial_estimado": 85.00, "valor_inova_estimado": 76.50, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE181916", "descricao": "Vedação Retentor John Deere", "categoria": "Vedação", "valor_oficial_estimado": 95.00, "valor_inova_estimado": 85.50, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "R116162", "descricao": "Anel Segmento John Deere", "categoria": "Motor", "valor_oficial_estimado": 420.00, "valor_inova_estimado": 378.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "R116163", "descricao": "Anel Segmento John Deere", "categoria": "Motor", "valor_oficial_estimado": 440.00, "valor_inova_estimado": 396.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE505980", "descricao": "Bomba Água John Deere", "categoria": "Motor", "valor_oficial_estimado": 1800.00, "valor_inova_estimado": 1620.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE505981", "descricao": "Bomba Água John Deere", "categoria": "Motor", "valor_oficial_estimado": 1950.00, "valor_inova_estimado": 1755.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE518503", "descricao": "Bomba Combustível John Deere", "categoria": "Motor", "valor_oficial_estimado": 850.00, "valor_inova_estimado": 765.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE518504", "descricao": "Bomba Combustível John Deere", "categoria": "Motor", "valor_oficial_estimado": 920.00, "valor_inova_estimado": 828.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AL156625", "descricao": "Lâmina Doce John Deere (plaina)", "categoria": "Implemento", "valor_oficial_estimado": 2500.00, "valor_inova_estimado": 2250.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AL156626", "descricao": "Lâmina Doce John Deere (plaina)", "categoria": "Implemento", "valor_oficial_estimado": 2650.00, "valor_inova_estimado": 2385.00, "menor_preco_paralelo": None, "fonte_menor": "EG Peças", "url_fonte": "https://egindustriadepecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "H206433", "descricao": "Pino Desgaste John Deere (plantadeira)", "categoria": "Desgaste", "valor_oficial_estimado": 120.00, "valor_inova_estimado": 108.00, "menor_preco_paralelo": None, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "H206434", "descricao": "Pino Desgaste John Deere (plantadeira)", "categoria": "Desgaste", "valor_oficial_estimado": 135.00, "valor_inova_estimado": 121.50, "menor_preco_paralelo": None, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "H206435", "descricao": "Pino Desgaste John Deere (plantadeira)", "categoria": "Desgaste", "valor_oficial_estimado": 145.00, "valor_inova_estimado": 130.50, "menor_preco_paralelo": None, "fonte_menor": "TBL Agro Peças", "url_fonte": "https://loja.tblagropecas.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AA37229", "descricao": "Bico Injetor John Deere", "categoria": "Motor", "valor_oficial_estimado": 1200.00, "valor_inova_estimado": 1080.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "AA37230", "descricao": "Bico Injetor John Deere", "categoria": "Motor", "valor_oficial_estimado": 1250.00, "valor_inova_estimado": 1125.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE500432", "descricao": "Elemento Filtrante Ar John Deere", "categoria": "Filtro", "valor_oficial_estimado": 350.00, "valor_inova_estimado": 315.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE500433", "descricao": "Elemento Filtrante Ar John Deere", "categoria": "Filtro", "valor_oficial_estimado": 380.00, "valor_inova_estimado": 342.00, "menor_preco_paralelo": None, "fonte_menor": "Ditrac", "url_fonte": "https://www.ditrac.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE210865", "descricao": "Sensor John Deere", "categoria": "Eletrônica", "valor_oficial_estimado": 650.00, "valor_inova_estimado": 585.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE210866", "descricao": "Sensor John Deere", "categoria": "Eletrônica", "valor_oficial_estimado": 720.00, "valor_inova_estimado": 648.00, "menor_preco_paralelo": None, "fonte_menor": "Rech Peças", "url_fonte": "https://www.rech.com", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE508822", "descricao": "Mangueira Hidráulica John Deere", "categoria": "Hidráulico", "valor_oficial_estimado": 280.00, "valor_inova_estimado": 252.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
    {"numero_peca": "RE508823", "descricao": "Mangueira Hidráulica John Deere", "categoria": "Hidráulico", "valor_oficial_estimado": 310.00, "valor_inova_estimado": 279.00, "menor_preco_paralelo": None, "fonte_menor": "Super Tractor", "url_fonte": "https://www.supertractor.com.br", "data_pesquisa": "06/05/2026", "status": "Preço sob orçamento"},
]

df = pd.DataFrame(pecas)

# Calcular diferença percentual Inova vs menor paralelo
df['diferenca_inova_paralelo_pct'] = df.apply(
    lambda row: round(((row['valor_inova_estimado'] - row['menor_preco_paralelo']) / row['valor_inova_estimado'] * 100), 1) 
    if pd.notna(row['menor_preco_paralelo']) and row['menor_preco_paralelo'] > 0 and pd.notna(row['valor_inova_estimado']) and row['valor_inova_estimado'] > 0 
    else None, axis=1
)

# Calcular diferença absoluta Inova vs menor paralelo
df['diferenca_inova_paralelo_abs'] = df.apply(
    lambda row: round(row['menor_preco_paralelo'] - row['valor_inova_estimado'], 2) 
    if pd.notna(row['menor_preco_paralelo']) and pd.notna(row['valor_inova_estimado']) 
    else None, axis=1
)

# Conclusão competitiva simplificada
def conclusao(row):
    if pd.isna(row['menor_preco_paralelo']):
        return "Pesquisa pendente"
    diff = row['diferenca_inova_paralelo_abs']
    if diff > 0:
        return "Inova mais competitiva"
    elif diff < 0:
        return "Paralelo mais barato"
    else:
        return "Preços equivalentes"

df['conclusao'] = df.apply(conclusao, axis=1)

# Nova estrutura simplificada - APENAS o mais barato do mercado paralelo
excel_cols = [
    'numero_peca', 'descricao', 'categoria',
    'valor_oficial_estimado', 'valor_inova_estimado',
    'menor_preco_paralelo', 'fonte_menor', 'url_fonte',
    'diferenca_inova_paralelo_abs', 'diferenca_inova_paralelo_pct',
    'conclusao', 'data_pesquisa', 'status'
]

df_excel = df[excel_cols].copy()
df_excel.columns = [
    'Número Peça John Deere', 'Descrição', 'Categoria',
    'Valor Oficial John Deere (R$)', 'Valor Praticado Inova (R$)',
    'Menor Preço Mercado Paralelo (R$)', 'Concorrente Mais Barato', 'URL Fonte',
    'Diferença Inova vs Paralelo (R$)', 'Diferença %',
    'Conclusão Competitiva', 'Data Pesquisa', 'Status Pesquisa'
]

# Criar Excel formatado
wb = Workbook()
ws = wb.active
ws.title = "Pesquisa Preços"

# Estilos
header_fill = PatternFill(start_color="006400", end_color="006400", fill_type="solid")
header_font = Font(color="FFFFFF", bold=True, size=11)
verde_fill = PatternFill(start_color="E2EFDA", end_color="E2EFDA", fill_type="solid")
amarelo_fill = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
vermelho_fill = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")

thin_border = Border(left=Side(style='thin'), right=Side(style='thin'), top=Side(style='thin'), bottom=Side(style='thin'))

# Escrever dados
for r_idx, row in enumerate(dataframe_to_rows(df_excel, index=False, header=True), 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws.cell(row=r_idx, column=c_idx, value=value)
        cell.border = thin_border
        cell.alignment = Alignment(vertical='center', wrap_text=True)
        
        if r_idx == 1:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center', wrap_text=True)
        else:
            conclusao_val = ws.cell(row=r_idx, column=11).value
            if conclusao_val == "Inova mais competitiva":
                cell.fill = verde_fill
            elif conclusao_val == "Paralelo mais barato":
                cell.fill = vermelho_fill
            elif conclusao_val == "Pesquisa pendente":
                cell.fill = amarelo_fill

# Ajustar larguras
ws.column_dimensions['A'].width = 15
ws.column_dimensions['B'].width = 50
ws.column_dimensions['C'].width = 15
ws.column_dimensions['D'].width = 18
ws.column_dimensions['E'].width = 18
ws.column_dimensions['F'].width = 18
ws.column_dimensions['G'].width = 25
ws.column_dimensions['H'].width = 35
ws.column_dimensions['I'].width = 18
ws.column_dimensions['J'].width = 12
ws.column_dimensions['K'].width = 22
ws.column_dimensions['L'].width = 13
ws.column_dimensions['M'].width = 18

# Congelar painel
ws.freeze_panes = 'A2'

# Aba Resumo
ws_resumo = wb.create_sheet("Resumo")

pesquisados = len(df[df['status'] == 'Pesquisado'])
pendentes = len(df[df['status'] != 'Pesquisado'])
inova_mais_comp = len(df[(df['conclusao'] == 'Inova mais competitiva') & (df['status'] == 'Pesquisado')])
paralelo_mais_bar = len(df[(df['conclusao'] == 'Paralelo mais barato') & (df['status'] == 'Pesquisado')])

resumo_data = [
    ["PESQUISA DE PREÇOS JOHN DEERE - MERCADO PARALELO"],
    ["Concessionária Inova - Demonstração"],
    [""],
    ["Data da pesquisa:", "06/05/2026"],
    ["Total de peças analisadas:", len(df)],
    ["Peças com preço pesquisado:", pesquisados],
    ["Peças com pesquisa pendente:", pendentes],
    [""],
    ["RESULTADO COMPETITIVO (peças pesquisadas):"],
    ["Inova mais competitiva:", inova_mais_comp],
    ["Paralelo mais barato:", paralelo_mais_bar],
    [""],
    ["MAIORES CONCORRENTES MAPEADOS:"],
    ["• EG Peças (Santo André/SP) - Grande porte, 25+ anos"],
    ["• Super Tractor (Santa Maria/RS) - Grande porte, múltiplas filiais"],
    ["• Rech Peças (Querência/MT) - Grande porte, rede Centro-Oeste e Norte"],
    ["• Ditrac (Várzea Grande/MT) - Grande porte, desde 1990"],
    ["• TBL Agro Peças (São Paulo/SP) - Médio porte, peças alternativas JD"],
    [""],
    ["OBSERVAÇÃO:"],
    ["Valores 'Oficial John Deere' e 'Inova' são ESTIMADOS para demonstração."],
    ["Substituir pelos valores reais do banco de dados da concessionária."],
    ["Preços paralelos com status 'Preço sob orçamento' requerem contato direto"],
    ["com o concorrente para obtenção do valor real."],
]

for r_idx, row in enumerate(resumo_data, 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws_resumo.cell(row=r_idx, column=c_idx, value=value)
        if r_idx == 1:
            cell.font = Font(bold=True, size=14, color="006400")
        elif r_idx == 9:
            cell.font = Font(bold=True, size=11)
        elif r_idx == 20:
            cell.font = Font(bold=True, color="C00000")

ws_resumo.column_dimensions['A'].width = 35
ws_resumo.column_dimensions['B'].width = 65

# Aba Concorrentes
ws_conc = wb.create_sheet("Concorrentes Mapeados")

concorrentes_data = [
    ["Empresa", "Cidade", "UF", "Tamanho", "Website", "Segmento", "Marcas"],
    ["EG Peças", "Santo André", "SP", "Grande", "egindustriadepecas.com.br", "Peças agrícolas e linha pesada", "John Deere, AGCO, Valtra, MF"],
    ["Super Tractor", "Santa Maria", "RS", "Grande", "supertractor.com.br", "Peças máquinas pesadas e agrícolas", "John Deere, Caterpillar, diversas"],
    ["TBL Agro Peças", "São Paulo", "SP", "Médio", "loja.tblagropecas.com.br", "Peças alternativas John Deere", "John Deere (alternativas)"],
    ["Rech Peças", "Querência", "MT", "Grande", "rech.com", "Peças máquinas pesadas e agrícolas", "Caterpillar, John Deere, JCB, etc."],
    ["Ditrac", "Várzea Grande", "MT", "Grande", "ditrac.com.br", "Peças tratores e implementos agrícolas", "John Deere, Valtra, MF, NH, Case"],
    ["Canaparts", "Online", "—", "Médio", "canaparts.com.br", "Peças John Deere", "John Deere"],
    ["Dispetral", "São Paulo", "SP", "Médio", "dispetral.com.br", "Peças linha amarela (construção)", "John Deere (linha amarela)"],
    ["BBX", "Online", "—", "Médio", "bbxtratores.com.br", "Peças tratores diversas marcas", "John Deere, Caterpillar, etc."],
    ["Pangea Parts", "São Paulo", "SP", "Médio", "pangeaparts.com.br", "Marketplace peças agrícolas", "Diversas"],
    ["MF Rural", "Online", "BR", "Grande", "mfrural.com.br", "Classificados agrícolas", "John Deere (anúncios)"],
    ["Mercado Livre", "São Paulo", "SP", "Gigante", "mercadolivre.com.br", "Marketplace geral", "John Deere (anúncios)"],
    ["Agrofy", "São Paulo", "SP", "Grande", "agrofy.com.br", "Marketplace agrícola", "John Deere (anúncios)"],
]

for r_idx, row in enumerate(concorrentes_data, 1):
    for c_idx, value in enumerate(row, 1):
        cell = ws_conc.cell(row=r_idx, column=c_idx, value=value)
        cell.border = thin_border
        if r_idx == 1:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal='center', vertical='center')

ws_conc.column_dimensions['A'].width = 18
ws_conc.column_dimensions['B'].width = 15
ws_conc.column_dimensions['C'].width = 8
ws_conc.column_dimensions['D'].width = 12
ws_conc.column_dimensions['E'].width = 28
ws_conc.column_dimensions['F'].width = 35
ws_conc.column_dimensions['G'].width = 35

excel_path = 'output/pesquisa_precos_final_inova.xlsx'
wb.save(excel_path)

print(f"Excel final gerado: {excel_path}")
print(f"\nEstrutura da planilha:")
print(f"- Aba 'Pesquisa Preços': 56 peças com estrutura simplificada")
print(f"- Aba 'Resumo': resumo executivo")
print(f"- Aba 'Concorrentes Mapeados': 12 concorrentes")
print(f"\nPeças pesquisadas: {pesquisados}")
print(f"Inova mais competitiva: {inova_mais_comp}")
print(f"Paralelo mais barato: {paralelo_mais_bar}")
