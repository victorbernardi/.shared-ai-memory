
import os
import hashlib

os.makedirs('output', exist_ok=True)

# Listar arquivos gerados e extrair metadados para identificação
arquivos_info = []

files_to_map = [
    'output/script_1_mapeamento_concorrentes.py',
    'output/script_2_pesquisa_precos_gemini.py',
    'output/script_3_consolidacao_excel.py',
    'output/script_substituicao_automatica.py',
    'output/pesquisa_precos_final_inova.xlsx',
    'output/comparativo_precos_john_deere_inova.xlsx',
    'output/mapeamento_concorrentes_base.csv',
    'output/template_banco_inova.csv',
    'output/INSTRUCOES_SUBSTITUICAO.md',
    'output/PLAYBOOK_GEMINI_CLI.md',
    'output/README_PROJETO.md',
]

for filepath in files_to_map:
    if os.path.exists(filepath):
        size = os.path.getsize(filepath)
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            first_lines = []
            for i in range(10):
                line = f.readline()
                if not line:
                    break
                first_lines.append(line.rstrip())
        
        # Calcular hash dos primeiros 500 bytes
        with open(filepath, 'rb') as f:
            first_bytes = f.read(500)
            file_hash = hashlib.md5(first_bytes).hexdigest()[:8]
        
        arquivos_info.append({
            'nome_atual': os.path.basename(filepath),
            'caminho': filepath,
            'tamanho_bytes': size,
            'tamanho_kb': round(size/1024, 1),
            'hash_primeiros_500b': file_hash,
            'primeiras_linhas': first_lines,
        })

# Criar documento de identificação
ident_doc = '''# MAPA DE IDENTIFICAÇÃO DE ARQUIVOS
# Use este documento para o Gemini CLI identificar e renomear arquivos
# Projetos: Pesquisa de Preços John Deere - Inova

================================================================================
INSTRUÇÕES PARA O GEMINI CLI / ANTIGRAVITY
================================================================================

Tarefa: Você recebeu vários arquivos com nomes genéricos (script.py, script1.py, 
script2.py, etc.) ou sem contexto. Use este mapa para identificar cada um e 
renomear para a estrutura correta do playbook.

MÉTODO DE IDENTIFICAÇÃO (ordem de prioridade):
1. Compare o TAMANHO EM BYTES do arquivo
2. Compare o HASH MD5 dos primeiros 500 bytes
3. Compare as PRIMEIRAS 10 LINHAS (assinatura do código)
4. Use a combinação dos 3 para ter certeza absoluta

================================================================================
TABELA DE IDENTIFICAÇÃO
================================================================================

'''

for info in arquivos_info:
    ident_doc += f"""
--------------------------------------------------------------------
ARQUIVO: {info['nome_atual']}
--------------------------------------------------------------------
Tamanho:        {info['tamanho_bytes']} bytes ({info['tamanho_kb']} KB)
Hash (500b):    {info['hash_primeiros_500b']}
Nome correto:   [ver abaixo]

PRIMEIRAS 10 LINHAS (assinatura):
"""
    for i, line in enumerate(info['primeiras_linhas'], 1):
        ident_doc += f"  {i:2d}| {line}\n"
    ident_doc += "\n"

# Adicionar mapeamento de nome correto
ident_doc += '''
================================================================================
MAPEAMENTO: NOME ATUAL → NOME CORRETO (PLAYBOOK)
================================================================================

Com base no tamanho, hash e assinatura:

1. Tamanho ~6-7 KB, hash começando conforme abaixo, primeiras linhas com "MAPEAMENTO DE CONCORRENTES"
   → Renomear para: 01-MAPEAMENTO/mapear_concorrentes.py

2. Tamanho ~3-4 KB, hash conforme abaixo, primeiras linhas com "PESQUISA DE PREÇOS" e "PROMPT_PESQUISA_PRECO"
   → Renomear para: 02-PESQUISA/gerar_prompts_pesquisa.py

3. Tamanho ~5-6 KB, hash conforme abaixo, primeiras linhas com "CONSOLIDAÇÃO DE DADOS EM EXCEL"
   → Renomear para: 04-CONSOLIDACAO/consolidar_planilha.py

4. Tamanho ~7-8 KB, hash conforme abaixo, primeiras linhas com "SUBSTITUIÇÃO AUTOMÁTICA"
   → Renomear para: 03-BANCO/script_substituicao.py

5. Tamanho ~15-20 KB (arquivo binário Excel), contém planilha comparativa
   → Renomear para: output/pesquisa_precos_base.xlsx

6. Tamanho ~1-2 KB, CSV com "razao_social" e "nome_fantasia"
   → Renomear para: 01-MAPEAMENTO/concorrentes_base.csv

7. Tamanho ~0.5 KB, CSV com "numero_peca;valor_oficial"
   → Renomear para: 03-BANCO/template_dados_banco.csv

8. Tamanho ~3-4 KB, markdown com "SUBSTITUIÇÃO AUTOMÁTICA"
   → Renomear para: 03-BANCO/INSTRUCOES.md

9. Tamanho ~11-12 KB, markdown com "PLAYBOOK GEMINI CLI"
   → Renomear para: PLAYBOOK_GEMINI_CLI.md

================================================================================
COMANDO DE RENOMEAÇÃO AUTOMÁTICA (bash)
================================================================================

Crie a estrutura de diretórios:
    mkdir -p 01-MAPEAMENTO 02-PESQUISA 03-BANCO 04-CONSOLIDACAO output

Depois renomeie usando os identificadores acima:
    mv [arquivo_identificado_1] 01-MAPEAMENTO/mapear_concorrentes.py
    mv [arquivo_identificado_2] 02-PESQUISA/gerar_prompts_pesquisa.py
    mv [arquivo_identificado_3] 04-CONSOLIDACAO/consolidar_planilha.py
    mv [arquivo_identificado_4] 03-BANCO/script_substituicao.py
    mv [arquivo_identificado_5] output/pesquisa_precos_base.xlsx
    mv [arquivo_identificado_6] 01-MAPEAMENTO/concorrentes_base.csv
    mv [arquivo_identificado_7] 03-BANCO/template_dados_banco.csv

================================================================================
SCRIPT PYTHON DE IDENTIFICAÇÃO AUTOMÁTICA
================================================================================

O Gemini CLI pode executar este script Python para identificar sozinho:

```python
import os

# Mapeamento de assinaturas conhecidas
SIGNATURES = {
    "01-MAPEAMENTO/mapear_concorrentes.py": {
        "keywords": ["MAPEAMENTO", "CONCORRENTES", "geodesic", "Nominatim"],
        "min_size": 6000,
        "max_size": 8000,
    },
    "02-PESQUISA/gerar_prompts_pesquisa.py": {
        "keywords": ["PESQUISA", "PROMPT_PESQUISA_PRECO", "Gemini CLI"],
        "min_size": 3000,
        "max_size": 5000,
    },
    "04-CONSOLIDACAO/consolidar_planilha.py": {
        "keywords": ["CONSOLIDAÇÃO", "ExcelWriter", "dados_banco"],
        "min_size": 4000,
        "max_size": 7000,
    },
    "03-BANCO/script_substituicao.py": {
        "keywords": ["SUBSTITUIÇÃO", "dados_reais_banco", "valor_oficial"],
        "min_size": 6000,
        "max_size": 9000,
    },
}

def identify_file(filepath):
    size = os.path.getsize(filepath)
    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
        content = f.read(2000)
    
    for name, sig in SIGNATURES.items():
        if sig["min_size"] <= size <= sig["max_size"]:
            matches = sum(1 for kw in sig["keywords"] if kw in content)
            if matches >= 2:
                return name
    return None
```

================================================================================
'''

with open('output/MAPA_IDENTIFICACAO_ARQUIVOS.md', 'w') as f:
    f.write(ident_doc)

print(f"Documento de identificação criado: output/MAPA_IDENTIFICACAO_ARQUIVOS.md")
print(f"Total de arquivos mapeados: {len(arquivos_info)}")
for info in arquivos_info:
    print(f"  {info['nome_atual']}: {info['tamanho_bytes']} bytes, hash={info['hash_primeiros_500b']}")
