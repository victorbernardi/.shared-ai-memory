# PROJETO: Pesquisa de Preços John Deere - Mercado Paralelo

## Estrutura do Projeto

| Arquivo | Função |
|---|---|
| `script_1_mapeamento_concorrentes.py` | Mapeia concorrentes nacionais e regionais |
| `script_2_pesquisa_precos_gemini.py` | Prompts para o Gemini CLI / Antigravity |
| `script_3_consolidacao_excel.py` | Consolida dados do BD + pesquisa em Excel |

## Fluxo de Trabalho

### Fase 1: Mapeamento de Concorrentes
```bash
python script_1_mapeamento_concorrentes.py
```
- Gera: `mapeamento_concorrentes_john_deere.xlsx`

### Fase 2: Pesquisa de Preços (Gemini CLI)
1. Exporte a lista de peças do seu banco:
```python
from script_3_consolidacao_excel import exportar_lista_pecas_para_pesquisa
exportar_lista_pecas_para_pesquisa(dados_banco)
```

2. Use o Gemini CLI com o prompt gerado:
```bash
gemini query "$(python script_2_pesquisa_precos_gemini.py SU300940)"
```

3. Salve os resultados JSON retornados pelo Gemini

### Fase 3: Consolidação
```bash
python script_3_consolidacao_excel.py
```
- Gera: `precos_comparativo_john_deere.xlsx`

## Concorrentes Nacionais Mapeados

| Empresa | Cidade | UF | Tamanho | Website |
|---|---|---|---|---|
| EG Peças | Santo André | SP | Grande | egindustriadepecas.com.br |
| Super Tractor | Santa Maria | RS | Grande | supertractor.com.br |
| TBL Agro Peças | São Paulo | SP | Médio | loja.tblagropecas.com.br |
| Rech Peças | Querência | MT | Grande | rech.com |
| Ditrac | Várzea Grande | MT | Grande | ditrac.com.br |
| Canaparts | N/A | N/A | Médio | canaparts.com.br |
| Dispetral | São Paulo | SP | Médio | dispetral.com.br |
| BBX | N/A | N/A | Médio | bbxtratores.com.br |
| Pangea Parts | São Paulo | SP | Médio | pangeaparts.com.br |
| MF Rural | Online | BR | Grande | mfrural.com.br |
| Mercado Livre | São Paulo | SP | Gigante | mercadolivre.com.br |
| Agrofy | São Paulo | SP | Grande | agrofy.com.br |

## Requisitos
- Python 3.9+
- pandas, openpyxl, geopy, requests
- Google Maps API Key (opcional para distâncias precisas)
- Gemini CLI ou Antigravity instalado
- Acesso ao banco de dados Inova (exportar via CSV/SQL)
