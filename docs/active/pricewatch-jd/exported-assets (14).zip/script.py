
import json
import os

# Criar diretório de output
os.makedirs('output', exist_ok=True)

# Script 1: Mapeamento de Concorrentes (Python)
script_mapeamento = '''#!/usr/bin/env python3
"""
SCRIPT 1: MAPEAMENTO DE CONCORRENTES - MERCADO PARALELO PEÇAS JOHN DEERE
Objetivo: Identificar, classificar e mapear concorrentes próximos às lojas Inova
"""

import pandas as pd
import requests
import time
from geopy.distance import geodesic
from geopy.geocoders import Nominatim
import json

# ============== CONFIGURAÇÃO ==============
# API Key do Google Maps (opcional - para geocoding e distância precisa)
GOOGLE_MAPS_API_KEY = "SUA_CHAVE_API_AQUI"

# Lojas Inova (lat/lon aproximados - atualizar com coordenadas reais)
LOJAS_INOVA = [
    {"nome": "Inova Contagem", "cidade": "Contagem", "uf": "MG", "lat": -19.9316, "lon": -44.0538},
    {"nome": "Inova Pouso Alegre", "cidade": "Pouso Alegre", "uf": "MG", "lat": -22.2282, "lon": -45.9386},
    {"nome": "Inova Montes Claros", "cidade": "Montes Claros", "uf": "MG", "lat": -16.7286, "lon": -43.8582},
    {"nome": "Inova Gov. Valadares", "cidade": "Governador Valadares", "uf": "MG", "lat": -18.8549, "lon": -41.9558},
    {"nome": "Inova Janaúba", "cidade": "Janaúba", "uf": "MG", "lat": -15.8027, "lon": -43.3130},
    {"nome": "Inova Pompéu", "cidade": "Pompéu", "uf": "MG", "lat": -19.2256, "lon": -44.9356},
    {"nome": "Inova Alfredo Vasconcelos", "cidade": "Alfredo Vasconcelos", "uf": "MG", "lat": -21.1535, "lon": -43.7719},
    {"nome": "Inova Serra", "cidade": "Serra", "uf": "ES", "lat": -20.1215, "lon": -40.3074},
    {"nome": "Inova Tanguá", "cidade": "Tanguá", "uf": "RJ", "lat": -22.7333, "lon": -42.7136},
]

# Concorrentes nacionais já identificados (base de dados inicial)
CONCORRENTES_BASE = [
    {"razao_social": "EG Indústria e Comércio de Peças", "nome_fantasia": "EG Peças", "cnpj": "03.023.315/0001-42", "cidade": "Santo André", "uf": "SP", "endereco": "Av. da Saudade, 127", "segmento": "Peças agrícolas e linha pesada", "website": "https://egindustriadepecas.com.br", "ano_fundacao": 1999, "tamanho": "Grande", "marcas": "John Deere, AGCO, Valtra, Massey Ferguson", "lat": -23.6739, "lon": -46.5289},
    {"razao_social": "Super Tractor Peças e Serviços", "nome_fantasia": "Super Tractor", "cnpj": "N/A", "cidade": "Santa Maria", "uf": "RS", "endereco": "BR 158 Km 327, 2600", "segmento": "Peças máquinas pesadas e agrícolas", "website": "https://www.supertractor.com.br", "ano_fundacao": 2005, "tamanho": "Grande", "marcas": "John Deere, Caterpillar, diversas", "lat": -29.6914, "lon": -53.8061},
    {"razao_social": "TBL Agro Peças", "nome_fantasia": "TBL Agro Peças", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online/SP", "segmento": "Peças alternativas John Deere", "website": "https://loja.tblagropecas.com.br", "ano_fundacao": 2018, "tamanho": "Médio", "marcas": "John Deere (alternativas)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "Rech Comércio de Peças", "nome_fantasia": "Rech Peças", "cnpj": "N/A", "cidade": "Querência", "uf": "MT", "endereco": "Av. Sul, 1126", "segmento": "Peças máquinas pesadas e agrícolas", "website": "https://rech.com", "ano_fundacao": 2010, "tamanho": "Grande", "marcas": "Caterpillar, John Deere, JCB, Case, New Holland, Hyundai, Volvo", "lat": -10.5833, "lon": -52.3000},
    {"razao_social": "Ditrac Agrícola Parts", "nome_fantasia": "Ditrac", "cnpj": "N/A", "cidade": "Várzea Grande", "uf": "MT", "endereco": "Av. da FEB, 1000", "segmento": "Peças tratores e implementos agrícolas", "website": "https://www.ditrac.com.br", "ano_fundacao": 1990, "tamanho": "Grande", "marcas": "Massey Ferguson, John Deere, Valtra, New Holland, Case, Agrale, CBT", "lat": -15.6461, "lon": -56.1325},
    {"razao_social": "Canaparts Indústria e Comércio", "nome_fantasia": "Canaparts", "cnpj": "N/A", "cidade": "N/A", "uf": "N/A", "endereco": "N/A", "segmento": "Peças John Deere", "website": "https://canaparts.com.br", "ano_fundacao": 2015, "tamanho": "Médio", "marcas": "John Deere", "lat": None, "lon": None},
    {"razao_social": "Dispetral", "nome_fantasia": "Dispetral", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "N/A", "segmento": "Peças linha amarela (construção)", "website": "https://www.dispetral.com.br", "ano_fundacao": 2000, "tamanho": "Médio", "marcas": "John Deere (linha amarela)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "BBX Indústria", "nome_fantasia": "BBX", "cnpj": "N/A", "cidade": "N/A", "uf": "N/A", "endereco": "N/A", "segmento": "Peças tratores diversas marcas", "website": "https://www.bbxtratores.com.br", "ano_fundacao": 2012, "tamanho": "Médio", "marcas": "Caterpillar, Komatsu, Hyundai, Volvo, New Holland, John Deere, Liebherr", "lat": None, "lon": None},
    {"razao_social": "Pangea Parts", "nome_fantasia": "Pangea Parts", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace peças agrícolas", "website": "https://www.pangeaparts.com.br", "ano_fundacao": 2019, "tamanho": "Médio", "marcas": "Diversas (incl. ZF)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "MF Rural Marketplace", "nome_fantasia": "MF Rural", "cnpj": "N/A", "cidade": "Online", "uf": "BR", "endereco": "Online", "segmento": "Classificados agrícolas", "website": "https://www.mfrural.com.br", "ano_fundacao": 2008, "tamanho": "Grande", "marcas": "John Deere e diversas (anúncios)", "lat": None, "lon": None},
    {"razao_social": "Mercado Livre", "nome_fantasia": "Mercado Livre", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace geral", "website": "https://www.mercadolivre.com.br", "ano_fundacao": 1999, "tamanho": "Gigante", "marcas": "John Deere e diversas (anúncios)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "Agrofy", "nome_fantasia": "Agrofy", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace agrícola", "website": "https://www.agrofy.com.br", "ano_fundacao": 2016, "tamanho": "Grande", "marcas": "John Deere e diversas", "lat": -23.5505, "lon": -46.6333},
]

# ============== FUNÇÕES ==============

def consultar_cnpj(cnpj):
    """Consulta dados de CNPJ via ReceitaWS"""
    cnpj_limpo = cnpj.replace('.', '').replace('/', '').replace('-', '')
    try:
        resp = requests.get(f"https://receitaws.com.br/v1/cnpj/{cnpj_limpo}", timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        print(f"Erro ao consultar CNPJ {cnpj}: {e}")
    return None

def calcular_distancia(loja_inova, concorrente):
    """Calcula distância em km entre loja Inova e concorrente"""
    if concorrente.get('lat') is None or concorrente.get('lon') is None:
        return None
    origem = (loja_inova['lat'], loja_inova['lon'])
    destino = (concorrente['lat'], concorrente['lon'])
    return round(geodesic(origem, destino).kilometers, 1)

def buscar_concorrentes_locais(loja, raio_km=200):
    """Busca concorrentes dentro de um raio da loja Inova"""
    resultados = []
    for c in CONCORRENTES_BASE:
        dist = calcular_distancia(loja, c)
        if dist is not None and dist <= raio_km:
            resultados.append({
                **c,
                "distancia_km": dist,
                "loja_inova_referencia": loja['nome']
            })
    return resultados

def pesquisar_novos_concorrentes(termo_busca="peças John Deere", local="Brasil"):
    """
    Pesquisa novos concorrentes via Google Custom Search API
    Requer API Key do Google Custom Search
    """
    API_KEY = "SUA_GOOGLE_API_KEY"
    CX = "SUA_CUSTOM_SEARCH_ENGINE_ID"
    
    query = f"{termo_busca} {local}"
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": API_KEY,
        "cx": CX,
        "q": query,
        "num": 10
    }
    
    try:
        resp = requests.get(url, params=params, timeout=20)
        data = resp.json()
        resultados = []
        for item in data.get('items', []):
            resultados.append({
                "titulo": item.get('title'),
                "link": item.get('link'),
                "snippet": item.get('snippet'),
                "fonte": "Google Search API"
            })
        return resultados
    except Exception as e:
        print(f"Erro na pesquisa: {e}")
        return []

def gerar_excel_mapeamento():
    """Gera planilha Excel com mapeamento completo"""
    
    # 1. Concorrentes Nacionais
    df_nacional = pd.DataFrame(CONCORRENTES_BASE)
    
    # 2. Concorrentes por Loja Inova (dentro de 300km)
    dados_locais = []
    for loja in LOJAS_INOVA:
        concorrentes_proximos = buscar_concorrentes_locais(loja, raio_km=300)
        for c in concorrentes_proximos:
            dados_locais.append({
                "Loja Inova": loja['nome'],
                "Cidade Inova": loja['cidade'],
                "UF Inova": loja['uf'],
                "Concorrente": c['nome_fantasia'],
                "Cidade Concorrente": c['cidade'],
                "UF Concorrente": c['uf'],
                "Distância (km)": c['distancia_km'],
                "Tamanho": c['tamanho'],
                "Website": c['website'],
                "Segmento": c['segmento'],
                "Marcas": c['marcas']
            })
    
    df_locais = pd.DataFrame(dados_locais)
    
    # Salvar Excel
    with pd.ExcelWriter("mapeamento_concorrentes_john_deere.xlsx", engine='openpyxl') as writer:
        df_nacional.to_excel(writer, sheet_name="Concorrentes_Nacionais", index=False)
        df_locais.to_excel(writer, sheet_name="Concorrentes_por_Loja", index=False)
    
    print("Excel gerado: mapeamento_concorrentes_john_deere.xlsx")
    return df_nacional, df_locais

if __name__ == "__main__":
    print("Iniciando mapeamento de concorrentes...")
    df_nac, df_loc = gerar_excel_mapeamento()
    print(f"Concorrentes nacionais mapeados: {len(df_nac)}")
    print(f"Relações loja-concorrente (300km): {len(df_loc)}")
'''

# Script 2: Pesquisa de Preços via Gemini CLI / Antigravity
script_pesquisa_precos = '''#!/usr/bin/env python3
"""
SCRIPT 2: PESQUISA DE PREÇOS - GEMINI CLI / ANTIGRAVITY
Este módulo gera os prompts/instruções para o agente de IA fazer a pesquisa
"""

PROMPT_PESQUISA_PRECO = """
Você é um pesquisador de preços especializado em peças agrícolas John Deere.
Sua missão é encontrar o preço de venda da peça número {numero_peca} no mercado paralelo.

## Instruções de Pesquisa:
1. Pesquise a peça {numero_peca} nos seguintes sites (nesta ordem de prioridade):
   - EG Peças: https://egindustriadepecas.com.br/pecas-johndeere/
   - TBL Agro Peças: https://loja.tblagropecas.com.br
   - Super Tractor: https://www.supertractor.com.br/pecas-maquinas-john-deere
   - Ditrac: https://www.ditrac.com.br/pecas-john-deere
   - Rech: https://rech.com
   - Canaparts: https://canaparts.com.br/pecas-john-deere
   - Mercado Livre: busca por "{numero_peca} John Deere"
   - MF Rural: busca por "{numero_peca} John Deere"
   - Agrofy: busca por "{numero_peca} John Deere"
   - Google Shopping: busca por "{numero_peca} John Deere"

2. Para CADA fonte onde encontrar a peça, capture:
   - Nome da empresa/fonte
   - Preço encontrado (em R$)
   - URL exata da página
   - Disponibilidade (em estoque / sob consulta / indisponível)
   - Data da consulta (hoje)

3. Se a peça não for encontrada em um site, registre como "Não encontrado".

4. Retorne os dados no seguinte formato JSON:
```json
{
  "numero_peca": "{numero_peca}",
  "data_pesquisa": "YYYY-MM-DD",
  "resultados": [
    {
      "fonte": "Nome da Empresa",
      "url": "https://...",
      "preco": "R$ X.XXX,XX",
      "disponibilidade": "em estoque",
      "observacao": "preço à vista / parcelado / com desconto"
    }
  ],
  "menor_preco_encontrado": "R$ X.XXX,XX",
  "maior_preco_encontrado": "R$ X.XXX,XX",
  "media_preco": "R$ X.XXX,XX"
}
```

5. IMPORTANTE: Sempre verifique se o preço é da peça EXATA (mesmo número) ou se é similar/compatível. Registre isso na observação.

Pesquise agora a peça {numero_peca} e retorne o JSON completo.
"""

PROMPT_PESQUISA_CONCORRENTE = """
Você é um analista de mercado especializado em peças agrícolas.
Encontre concorrentes do mercado paralelo de peças John Deere na região de {cidade}, {uf}.

## Tarefa:
1. Faça buscas no Google por:
   - "peças John Deere {cidade}"
   - "peças agrícolas John Deere {uf}"
   - "mercado paralelo John Deere {cidade}"
   - "reposição John Deere {cidade}"
   - "loja peças tratores {cidade}"

2. Para cada empresa encontrada, capture:
   - Nome da empresa
   - Endereço completo (se disponível)
   - Telefone/WhatsApp
   - Website/redes sociais
   - Tempo de mercado (se mencionado)
   - Porte da empresa (pequena/média/grande)
   - Marcas que trabalha
   - Se vende peças originais, paralelas ou ambas

3. Classifique por relevância:
   - Alta: vende peças John Deere paralelas e tem site/loja física
   - Média: vende peças agrícolas diversas, pode ter John Deere
   - Baixa: genérica, sem evidência de trabalhar com John Deere

4. Retorne em formato JSON.
"""

import json

def gerar_prompt_pesquisa(numero_peca):
    return PROMPT_PESQUISA_PRECO.format(numero_peca=numero_peca)

def gerar_prompt_concorrentes(cidade, uf):
    return PROMPT_PESQUISA_CONCORRENTE.format(cidade=cidade, uf=uf)

def processar_resultado_json(texto_json, numero_peca):
    """Processa o JSON retornado pelo Gemini CLI"""
    try:
        data = json.loads(texto_json)
        return data
    except json.JSONDecodeError:
        print(f"Erro ao parsear JSON para peça {numero_peca}")
        return None

if __name__ == "__main__":
    # Exemplo de uso:
    peca = "SU300940"
    print(gerar_prompt_pesquisa(peca))
'''

# Script 3: Consolidação em Excel
script_consolidacao = '''#!/usr/bin/env python3
"""
SCRIPT 3: CONSOLIDAÇÃO DE DADOS EM EXCEL
Integra dados do BD Inova + pesquisa Gemini CLI + mapeamento concorrentes
"""

import pandas as pd
import json
from datetime import datetime
import os

def consolidar_planilha(dados_banco, resultados_pesquisa, arquivo_saida="precos_comparativo_john_deere.xlsx"):
    """
    dados_banco: lista de dicts do seu BD Inova
    resultados_pesquisa: lista de dicts JSON retornados pelo Gemini CLI
    """
    
    linhas = []
    
    for item_bd in dados_banco:
        numero_peca = item_bd['numero_peca']
        descricao = item_bd.get('descricao', '')
        valor_oficial_jd = item_bd.get('valor_oficial_john_deere', None)
        valor_inova = item_bd.get('valor_inova', None)
        
        # Buscar resultados da pesquisa para esta peça
        pesquisa = next((p for p in resultados_pesquisa if p['numero_peca'] == numero_peca), None)
        
        if pesquisa:
            resultados = pesquisa.get('resultados', [])
            
            # Adicionar linha principal
            linha_base = {
                "Número Peça John Deere": numero_peca,
                "Descrição": descricao,
                "Valor Oficial John Deere (R$)": valor_oficial_jd,
                "Valor Praticado Inova (R$)": valor_inova,
                "Data Pesquisa": pesquisa.get('data_pesquisa', datetime.now().strftime('%Y-%m-%d')),
                "Menor Preço Mercado Paralelo (R$)": pesquisa.get('menor_preco_encontrado', ''),
                "Média Preço Mercado Paralelo (R$)": pesquisa.get('media_preco', ''),
                "Maior Preço Mercado Paralelo (R$)": pesquisa.get('maior_preco_encontrado', ''),
            }
            linhas.append(linha_base)
            
            # Adicionar linhas de detalhe por fonte
            for r in resultados:
                linhas.append({
                    "Número Peça John Deere": numero_peca,
                    "Descrição": descricao,
                    "Valor Oficial John Deere (R$)": "",
                    "Valor Praticado Inova (R$)": "",
                    "Data Pesquisa": "",
                    "Menor Preço Mercado Paralelo (R$)": "",
                    "Média Preço Mercado Paralelo (R$)": "",
                    "Maior Preço Mercado Paralelo (R$)": "",
                    "Fonte Detalhada": r.get('fonte', ''),
                    "URL Fonte": r.get('url', ''),
                    "Preço Encontrado (R$)": r.get('preco', ''),
                    "Disponibilidade": r.get('disponibilidade', ''),
                    "Observação": r.get('observacao', '')
                })
        else:
            # Sem pesquisa realizada
            linhas.append({
                "Número Peça John Deere": numero_peca,
                "Descrição": descricao,
                "Valor Oficial John Deere (R$)": valor_oficial_jd,
                "Valor Praticado Inova (R$)": valor_inova,
                "Data Pesquisa": "",
                "Menor Preço Mercado Paralelo (R$)": "PESQUISA PENDENTE",
                "Média Preço Mercado Paralelo (R$)": "",
                "Maior Preço Mercado Paralelo (R$)": "",
            })
    
    df = pd.DataFrame(linhas)
    
    # Salvar Excel com formatação
    with pd.ExcelWriter(arquivo_saida, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name="Comparativo Preços", index=False)
        
        # Ajustar largura das colunas
        worksheet = writer.sheets["Comparativo Preços"]
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 60)
            worksheet.column_dimensions[column_letter].width = adjusted_width
    
    print(f"Planilha consolidada gerada: {arquivo_saida}")
    print(f"Total de linhas: {len(df)}")
    return df

def exportar_lista_pecas_para_pesquisa(dados_banco, arquivo="lista_pecas_pesquisa.txt"):
    """Exporta lista de números de peças para o Gemini CLI pesquisar"""
    with open(arquivo, 'w') as f:
        for item in dados_banco:
            f.write(f"{item['numero_peca']}\\n")
    print(f"Lista exportada: {arquivo}")

if __name__ == "__main__":
    # Exemplo de estrutura dos dados do banco
    exemplo_banco = [
        {
            "numero_peca": "SU300940",
            "descricao": "Peça exemplo John Deere",
            "valor_oficial_john_deere": 1500.00,
            "valor_inova": 1350.00
        },
        {
            "numero_peca": "RE211277",
            "descricao": "Outra peça exemplo",
            "valor_oficial_john_deere": 2800.00,
            "valor_inova": 2520.00
        }
    ]
    
    exemplo_pesquisa = [
        {
            "numero_peca": "SU300940",
            "data_pesquisa": "2026-05-06",
            "resultados": [
                {"fonte": "EG Peças", "url": "https://egindustriadepecas.com.br", "preco": "R$ 1.200,00", "disponibilidade": "em estoque", "observacao": "preço à vista"},
                {"fonte": "Mercado Livre", "url": "https://mercadolivre.com.br", "preco": "R$ 1.350,00", "disponibilidade": "em estoque", "observacao": ""}
            ],
            "menor_preco_encontrado": "R$ 1.200,00",
            "maior_preco_encontrado": "R$ 1.350,00",
            "media_preco": "R$ 1.275,00"
        }
    ]
    
    consolidar_planilha(exemplo_banco, exemplo_pesquisa)
'''

# Salvar os scripts
with open('output/script_1_mapeamento_concorrentes.py', 'w') as f:
    f.write(script_mapeamento)

with open('output/script_2_pesquisa_precos_gemini.py', 'w') as f:
    f.write(script_pesquisa_precos)

with open('output/script_3_consolidacao_excel.py', 'w') as f:
    f.write(script_consolidacao)

# Criar README com instruções
readme = '''# PROJETO: Pesquisa de Preços John Deere - Mercado Paralelo

## Estrutura do Projeto

| Arquivo | Função |
|---|---|
| `script_1_mapeamento_concorrentes.py` | Mapeia concorrentes nacionais e regionais |
| `script_2_pesquisa_precos_gemini.py` | Prompts para o Gemini CLI / Antigravity |
| `script_3_consolidacao_excel.py` | Consolida dados do BD + pesquisa em Excel |

## Fluxo de Trabalho

### Fase 1: Mapeamento de Concorrentes
```bash
python script_1_mapeamento_concorrentes.py
```
- Gera: `mapeamento_concorrentes_john_deere.xlsx`

### Fase 2: Pesquisa de Preços (Gemini CLI)
1. Exporte a lista de peças do seu banco:
```python
from script_3_consolidacao_excel import exportar_lista_pecas_para_pesquisa
exportar_lista_pecas_para_pesquisa(dados_banco)
```

2. Use o Gemini CLI com o prompt gerado:
```bash
gemini query "$(python script_2_pesquisa_precos_gemini.py SU300940)"
```

3. Salve os resultados JSON retornados pelo Gemini

### Fase 3: Consolidação
```bash
python script_3_consolidacao_excel.py
```
- Gera: `precos_comparativo_john_deere.xlsx`

## Concorrentes Nacionais Mapeados

| Empresa | Cidade | UF | Tamanho | Website |
|---|---|---|---|---|
| EG Peças | Santo André | SP | Grande | egindustriadepecas.com.br |
| Super Tractor | Santa Maria | RS | Grande | supertractor.com.br |
| TBL Agro Peças | São Paulo | SP | Médio | loja.tblagropecas.com.br |
| Rech Peças | Querência | MT | Grande | rech.com |
| Ditrac | Várzea Grande | MT | Grande | ditrac.com.br |
| Canaparts | N/A | N/A | Médio | canaparts.com.br |
| Dispetral | São Paulo | SP | Médio | dispetral.com.br |
| BBX | N/A | N/A | Médio | bbxtratores.com.br |
| Pangea Parts | São Paulo | SP | Médio | pangeaparts.com.br |
| MF Rural | Online | BR | Grande | mfrural.com.br |
| Mercado Livre | São Paulo | SP | Gigante | mercadolivre.com.br |
| Agrofy | São Paulo | SP | Grande | agrofy.com.br |

## Requisitos
- Python 3.9+
- pandas, openpyxl, geopy, requests
- Google Maps API Key (opcional para distâncias precisas)
- Gemini CLI ou Antigravity instalado
- Acesso ao banco de dados Inova (exportar via CSV/SQL)
'''

with open('output/README_PROJETO.md', 'w') as f:
    f.write(readme)

print("Scripts gerados com sucesso!")
print("Arquivos criados em output/:")
print("- script_1_mapeamento_concorrentes.py")
print("- script_2_pesquisa_precos_gemini.py")
print("- script_3_consolidacao_excel.py")
print("- README_PROJETO.md")
