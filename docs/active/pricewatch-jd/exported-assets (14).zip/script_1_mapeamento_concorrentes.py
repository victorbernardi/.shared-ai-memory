#!/usr/bin/env python3
"""
SCRIPT 1: MAPEAMENTO DE CONCORRENTES - MERCADO PARALELO PEÇAS JOHN DEERE
Objetivo: Identificar, classificar e mapear concorrentes próximos às lojas Inova
"""

import pandas as pd
import requests
import time
from geopy.distance import geodesic
from geopy.geocoders import Nominatim
import json

# ============== CONFIGURAÇÃO ==============
# API Key do Google Maps (opcional - para geocoding e distância precisa)
GOOGLE_MAPS_API_KEY = "SUA_CHAVE_API_AQUI"

# Lojas Inova (lat/lon aproximados - atualizar com coordenadas reais)
LOJAS_INOVA = [
    {"nome": "Inova Contagem", "cidade": "Contagem", "uf": "MG", "lat": -19.9316, "lon": -44.0538},
    {"nome": "Inova Pouso Alegre", "cidade": "Pouso Alegre", "uf": "MG", "lat": -22.2282, "lon": -45.9386},
    {"nome": "Inova Montes Claros", "cidade": "Montes Claros", "uf": "MG", "lat": -16.7286, "lon": -43.8582},
    {"nome": "Inova Gov. Valadares", "cidade": "Governador Valadares", "uf": "MG", "lat": -18.8549, "lon": -41.9558},
    {"nome": "Inova Janaúba", "cidade": "Janaúba", "uf": "MG", "lat": -15.8027, "lon": -43.3130},
    {"nome": "Inova Pompéu", "cidade": "Pompéu", "uf": "MG", "lat": -19.2256, "lon": -44.9356},
    {"nome": "Inova Alfredo Vasconcelos", "cidade": "Alfredo Vasconcelos", "uf": "MG", "lat": -21.1535, "lon": -43.7719},
    {"nome": "Inova Serra", "cidade": "Serra", "uf": "ES", "lat": -20.1215, "lon": -40.3074},
    {"nome": "Inova Tanguá", "cidade": "Tanguá", "uf": "RJ", "lat": -22.7333, "lon": -42.7136},
]

# Concorrentes nacionais já identificados (base de dados inicial)
CONCORRENTES_BASE = [
    {"razao_social": "EG Indústria e Comércio de Peças", "nome_fantasia": "EG Peças", "cnpj": "03.023.315/0001-42", "cidade": "Santo André", "uf": "SP", "endereco": "Av. da Saudade, 127", "segmento": "Peças agrícolas e linha pesada", "website": "https://egindustriadepecas.com.br", "ano_fundacao": 1999, "tamanho": "Grande", "marcas": "John Deere, AGCO, Valtra, Massey Ferguson", "lat": -23.6739, "lon": -46.5289},
    {"razao_social": "Super Tractor Peças e Serviços", "nome_fantasia": "Super Tractor", "cnpj": "N/A", "cidade": "Santa Maria", "uf": "RS", "endereco": "BR 158 Km 327, 2600", "segmento": "Peças máquinas pesadas e agrícolas", "website": "https://www.supertractor.com.br", "ano_fundacao": 2005, "tamanho": "Grande", "marcas": "John Deere, Caterpillar, diversas", "lat": -29.6914, "lon": -53.8061},
    {"razao_social": "TBL Agro Peças", "nome_fantasia": "TBL Agro Peças", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online/SP", "segmento": "Peças alternativas John Deere", "website": "https://loja.tblagropecas.com.br", "ano_fundacao": 2018, "tamanho": "Médio", "marcas": "John Deere (alternativas)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "Rech Comércio de Peças", "nome_fantasia": "Rech Peças", "cnpj": "N/A", "cidade": "Querência", "uf": "MT", "endereco": "Av. Sul, 1126", "segmento": "Peças máquinas pesadas e agrícolas", "website": "https://rech.com", "ano_fundacao": 2010, "tamanho": "Grande", "marcas": "Caterpillar, John Deere, JCB, Case, New Holland, Hyundai, Volvo", "lat": -10.5833, "lon": -52.3000},
    {"razao_social": "Ditrac Agrícola Parts", "nome_fantasia": "Ditrac", "cnpj": "N/A", "cidade": "Várzea Grande", "uf": "MT", "endereco": "Av. da FEB, 1000", "segmento": "Peças tratores e implementos agrícolas", "website": "https://www.ditrac.com.br", "ano_fundacao": 1990, "tamanho": "Grande", "marcas": "Massey Ferguson, John Deere, Valtra, New Holland, Case, Agrale, CBT", "lat": -15.6461, "lon": -56.1325},
    {"razao_social": "Canaparts Indústria e Comércio", "nome_fantasia": "Canaparts", "cnpj": "N/A", "cidade": "N/A", "uf": "N/A", "endereco": "N/A", "segmento": "Peças John Deere", "website": "https://canaparts.com.br", "ano_fundacao": 2015, "tamanho": "Médio", "marcas": "John Deere", "lat": None, "lon": None},
    {"razao_social": "Dispetral", "nome_fantasia": "Dispetral", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "N/A", "segmento": "Peças linha amarela (construção)", "website": "https://www.dispetral.com.br", "ano_fundacao": 2000, "tamanho": "Médio", "marcas": "John Deere (linha amarela)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "BBX Indústria", "nome_fantasia": "BBX", "cnpj": "N/A", "cidade": "N/A", "uf": "N/A", "endereco": "N/A", "segmento": "Peças tratores diversas marcas", "website": "https://www.bbxtratores.com.br", "ano_fundacao": 2012, "tamanho": "Médio", "marcas": "Caterpillar, Komatsu, Hyundai, Volvo, New Holland, John Deere, Liebherr", "lat": None, "lon": None},
    {"razao_social": "Pangea Parts", "nome_fantasia": "Pangea Parts", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace peças agrícolas", "website": "https://www.pangeaparts.com.br", "ano_fundacao": 2019, "tamanho": "Médio", "marcas": "Diversas (incl. ZF)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "MF Rural Marketplace", "nome_fantasia": "MF Rural", "cnpj": "N/A", "cidade": "Online", "uf": "BR", "endereco": "Online", "segmento": "Classificados agrícolas", "website": "https://www.mfrural.com.br", "ano_fundacao": 2008, "tamanho": "Grande", "marcas": "John Deere e diversas (anúncios)", "lat": None, "lon": None},
    {"razao_social": "Mercado Livre", "nome_fantasia": "Mercado Livre", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace geral", "website": "https://www.mercadolivre.com.br", "ano_fundacao": 1999, "tamanho": "Gigante", "marcas": "John Deere e diversas (anúncios)", "lat": -23.5505, "lon": -46.6333},
    {"razao_social": "Agrofy", "nome_fantasia": "Agrofy", "cnpj": "N/A", "cidade": "São Paulo", "uf": "SP", "endereco": "Online", "segmento": "Marketplace agrícola", "website": "https://www.agrofy.com.br", "ano_fundacao": 2016, "tamanho": "Grande", "marcas": "John Deere e diversas", "lat": -23.5505, "lon": -46.6333},
]

# ============== FUNÇÕES ==============

def consultar_cnpj(cnpj):
    """Consulta dados de CNPJ via ReceitaWS"""
    cnpj_limpo = cnpj.replace('.', '').replace('/', '').replace('-', '')
    try:
        resp = requests.get(f"https://receitaws.com.br/v1/cnpj/{cnpj_limpo}", timeout=15)
        if resp.status_code == 200:
            return resp.json()
    except Exception as e:
        print(f"Erro ao consultar CNPJ {cnpj}: {e}")
    return None

def calcular_distancia(loja_inova, concorrente):
    """Calcula distância em km entre loja Inova e concorrente"""
    if concorrente.get('lat') is None or concorrente.get('lon') is None:
        return None
    origem = (loja_inova['lat'], loja_inova['lon'])
    destino = (concorrente['lat'], concorrente['lon'])
    return round(geodesic(origem, destino).kilometers, 1)

def buscar_concorrentes_locais(loja, raio_km=200):
    """Busca concorrentes dentro de um raio da loja Inova"""
    resultados = []
    for c in CONCORRENTES_BASE:
        dist = calcular_distancia(loja, c)
        if dist is not None and dist <= raio_km:
            resultados.append({
                **c,
                "distancia_km": dist,
                "loja_inova_referencia": loja['nome']
            })
    return resultados

def pesquisar_novos_concorrentes(termo_busca="peças John Deere", local="Brasil"):
    """
    Pesquisa novos concorrentes via Google Custom Search API
    Requer API Key do Google Custom Search
    """
    API_KEY = "SUA_GOOGLE_API_KEY"
    CX = "SUA_CUSTOM_SEARCH_ENGINE_ID"

    query = f"{termo_busca} {local}"
    url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "key": API_KEY,
        "cx": CX,
        "q": query,
        "num": 10
    }

    try:
        resp = requests.get(url, params=params, timeout=20)
        data = resp.json()
        resultados = []
        for item in data.get('items', []):
            resultados.append({
                "titulo": item.get('title'),
                "link": item.get('link'),
                "snippet": item.get('snippet'),
                "fonte": "Google Search API"
            })
        return resultados
    except Exception as e:
        print(f"Erro na pesquisa: {e}")
        return []

def gerar_excel_mapeamento():
    """Gera planilha Excel com mapeamento completo"""

    # 1. Concorrentes Nacionais
    df_nacional = pd.DataFrame(CONCORRENTES_BASE)

    # 2. Concorrentes por Loja Inova (dentro de 300km)
    dados_locais = []
    for loja in LOJAS_INOVA:
        concorrentes_proximos = buscar_concorrentes_locais(loja, raio_km=300)
        for c in concorrentes_proximos:
            dados_locais.append({
                "Loja Inova": loja['nome'],
                "Cidade Inova": loja['cidade'],
                "UF Inova": loja['uf'],
                "Concorrente": c['nome_fantasia'],
                "Cidade Concorrente": c['cidade'],
                "UF Concorrente": c['uf'],
                "Distância (km)": c['distancia_km'],
                "Tamanho": c['tamanho'],
                "Website": c['website'],
                "Segmento": c['segmento'],
                "Marcas": c['marcas']
            })

    df_locais = pd.DataFrame(dados_locais)

    # Salvar Excel
    with pd.ExcelWriter("mapeamento_concorrentes_john_deere.xlsx", engine='openpyxl') as writer:
        df_nacional.to_excel(writer, sheet_name="Concorrentes_Nacionais", index=False)
        df_locais.to_excel(writer, sheet_name="Concorrentes_por_Loja", index=False)

    print("Excel gerado: mapeamento_concorrentes_john_deere.xlsx")
    return df_nacional, df_locais

if __name__ == "__main__":
    print("Iniciando mapeamento de concorrentes...")
    df_nac, df_loc = gerar_excel_mapeamento()
    print(f"Concorrentes nacionais mapeados: {len(df_nac)}")
    print(f"Relações loja-concorrente (300km): {len(df_loc)}")
