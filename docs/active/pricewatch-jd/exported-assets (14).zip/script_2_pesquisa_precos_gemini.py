#!/usr/bin/env python3
"""
SCRIPT 2: PESQUISA DE PREÇOS - GEMINI CLI / ANTIGRAVITY
Este módulo gera os prompts/instruções para o agente de IA fazer a pesquisa
"""

PROMPT_PESQUISA_PRECO = """
Você é um pesquisador de preços especializado em peças agrícolas John Deere.
Sua missão é encontrar o preço de venda da peça número {numero_peca} no mercado paralelo.

## Instruções de Pesquisa:
1. Pesquise a peça {numero_peca} nos seguintes sites (nesta ordem de prioridade):
   - EG Peças: https://egindustriadepecas.com.br/pecas-johndeere/
   - TBL Agro Peças: https://loja.tblagropecas.com.br
   - Super Tractor: https://www.supertractor.com.br/pecas-maquinas-john-deere
   - Ditrac: https://www.ditrac.com.br/pecas-john-deere
   - Rech: https://rech.com
   - Canaparts: https://canaparts.com.br/pecas-john-deere
   - Mercado Livre: busca por "{numero_peca} John Deere"
   - MF Rural: busca por "{numero_peca} John Deere"
   - Agrofy: busca por "{numero_peca} John Deere"
   - Google Shopping: busca por "{numero_peca} John Deere"

2. Para CADA fonte onde encontrar a peça, capture:
   - Nome da empresa/fonte
   - Preço encontrado (em R$)
   - URL exata da página
   - Disponibilidade (em estoque / sob consulta / indisponível)
   - Data da consulta (hoje)

3. Se a peça não for encontrada em um site, registre como "Não encontrado".

4. Retorne os dados no seguinte formato JSON:
```json
{
  "numero_peca": "{numero_peca}",
  "data_pesquisa": "YYYY-MM-DD",
  "resultados": [
    {
      "fonte": "Nome da Empresa",
      "url": "https://...",
      "preco": "R$ X.XXX,XX",
      "disponibilidade": "em estoque",
      "observacao": "preço à vista / parcelado / com desconto"
    }
  ],
  "menor_preco_encontrado": "R$ X.XXX,XX",
  "maior_preco_encontrado": "R$ X.XXX,XX",
  "media_preco": "R$ X.XXX,XX"
}
```

5. IMPORTANTE: Sempre verifique se o preço é da peça EXATA (mesmo número) ou se é similar/compatível. Registre isso na observação.

Pesquise agora a peça {numero_peca} e retorne o JSON completo.
"""

PROMPT_PESQUISA_CONCORRENTE = """
Você é um analista de mercado especializado em peças agrícolas.
Encontre concorrentes do mercado paralelo de peças John Deere na região de {cidade}, {uf}.

## Tarefa:
1. Faça buscas no Google por:
   - "peças John Deere {cidade}"
   - "peças agrícolas John Deere {uf}"
   - "mercado paralelo John Deere {cidade}"
   - "reposição John Deere {cidade}"
   - "loja peças tratores {cidade}"

2. Para cada empresa encontrada, capture:
   - Nome da empresa
   - Endereço completo (se disponível)
   - Telefone/WhatsApp
   - Website/redes sociais
   - Tempo de mercado (se mencionado)
   - Porte da empresa (pequena/média/grande)
   - Marcas que trabalha
   - Se vende peças originais, paralelas ou ambas

3. Classifique por relevância:
   - Alta: vende peças John Deere paralelas e tem site/loja física
   - Média: vende peças agrícolas diversas, pode ter John Deere
   - Baixa: genérica, sem evidência de trabalhar com John Deere

4. Retorne em formato JSON.
"""

import json

def gerar_prompt_pesquisa(numero_peca):
    return PROMPT_PESQUISA_PRECO.format(numero_peca=numero_peca)

def gerar_prompt_concorrentes(cidade, uf):
    return PROMPT_PESQUISA_CONCORRENTE.format(cidade=cidade, uf=uf)

def processar_resultado_json(texto_json, numero_peca):
    """Processa o JSON retornado pelo Gemini CLI"""
    try:
        data = json.loads(texto_json)
        return data
    except json.JSONDecodeError:
        print(f"Erro ao parsear JSON para peça {numero_peca}")
        return None

if __name__ == "__main__":
    # Exemplo de uso:
    peca = "SU300940"
    print(gerar_prompt_pesquisa(peca))
