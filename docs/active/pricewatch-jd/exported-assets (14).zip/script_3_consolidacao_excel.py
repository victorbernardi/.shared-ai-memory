#!/usr/bin/env python3
"""
SCRIPT 3: CONSOLIDAÇÃO DE DADOS EM EXCEL
Integra dados do BD Inova + pesquisa Gemini CLI + mapeamento concorrentes
"""

import pandas as pd
import json
from datetime import datetime
import os

def consolidar_planilha(dados_banco, resultados_pesquisa, arquivo_saida="precos_comparativo_john_deere.xlsx"):
    """
    dados_banco: lista de dicts do seu BD Inova
    resultados_pesquisa: lista de dicts JSON retornados pelo Gemini CLI
    """

    linhas = []

    for item_bd in dados_banco:
        numero_peca = item_bd['numero_peca']
        descricao = item_bd.get('descricao', '')
        valor_oficial_jd = item_bd.get('valor_oficial_john_deere', None)
        valor_inova = item_bd.get('valor_inova', None)

        # Buscar resultados da pesquisa para esta peça
        pesquisa = next((p for p in resultados_pesquisa if p['numero_peca'] == numero_peca), None)

        if pesquisa:
            resultados = pesquisa.get('resultados', [])

            # Adicionar linha principal
            linha_base = {
                "Número Peça John Deere": numero_peca,
                "Descrição": descricao,
                "Valor Oficial John Deere (R$)": valor_oficial_jd,
                "Valor Praticado Inova (R$)": valor_inova,
                "Data Pesquisa": pesquisa.get('data_pesquisa', datetime.now().strftime('%Y-%m-%d')),
                "Menor Preço Mercado Paralelo (R$)": pesquisa.get('menor_preco_encontrado', ''),
                "Média Preço Mercado Paralelo (R$)": pesquisa.get('media_preco', ''),
                "Maior Preço Mercado Paralelo (R$)": pesquisa.get('maior_preco_encontrado', ''),
            }
            linhas.append(linha_base)

            # Adicionar linhas de detalhe por fonte
            for r in resultados:
                linhas.append({
                    "Número Peça John Deere": numero_peca,
                    "Descrição": descricao,
                    "Valor Oficial John Deere (R$)": "",
                    "Valor Praticado Inova (R$)": "",
                    "Data Pesquisa": "",
                    "Menor Preço Mercado Paralelo (R$)": "",
                    "Média Preço Mercado Paralelo (R$)": "",
                    "Maior Preço Mercado Paralelo (R$)": "",
                    "Fonte Detalhada": r.get('fonte', ''),
                    "URL Fonte": r.get('url', ''),
                    "Preço Encontrado (R$)": r.get('preco', ''),
                    "Disponibilidade": r.get('disponibilidade', ''),
                    "Observação": r.get('observacao', '')
                })
        else:
            # Sem pesquisa realizada
            linhas.append({
                "Número Peça John Deere": numero_peca,
                "Descrição": descricao,
                "Valor Oficial John Deere (R$)": valor_oficial_jd,
                "Valor Praticado Inova (R$)": valor_inova,
                "Data Pesquisa": "",
                "Menor Preço Mercado Paralelo (R$)": "PESQUISA PENDENTE",
                "Média Preço Mercado Paralelo (R$)": "",
                "Maior Preço Mercado Paralelo (R$)": "",
            })

    df = pd.DataFrame(linhas)

    # Salvar Excel com formatação
    with pd.ExcelWriter(arquivo_saida, engine='openpyxl') as writer:
        df.to_excel(writer, sheet_name="Comparativo Preços", index=False)

        # Ajustar largura das colunas
        worksheet = writer.sheets["Comparativo Preços"]
        for column in worksheet.columns:
            max_length = 0
            column_letter = column[0].column_letter
            for cell in column:
                try:
                    if len(str(cell.value)) > max_length:
                        max_length = len(str(cell.value))
                except:
                    pass
            adjusted_width = min(max_length + 2, 60)
            worksheet.column_dimensions[column_letter].width = adjusted_width

    print(f"Planilha consolidada gerada: {arquivo_saida}")
    print(f"Total de linhas: {len(df)}")
    return df

def exportar_lista_pecas_para_pesquisa(dados_banco, arquivo="lista_pecas_pesquisa.txt"):
    """Exporta lista de números de peças para o Gemini CLI pesquisar"""
    with open(arquivo, 'w') as f:
        for item in dados_banco:
            f.write(f"{item['numero_peca']}\n")
    print(f"Lista exportada: {arquivo}")

if __name__ == "__main__":
    # Exemplo de estrutura dos dados do banco
    exemplo_banco = [
        {
            "numero_peca": "SU300940",
            "descricao": "Peça exemplo John Deere",
            "valor_oficial_john_deere": 1500.00,
            "valor_inova": 1350.00
        },
        {
            "numero_peca": "RE211277",
            "descricao": "Outra peça exemplo",
            "valor_oficial_john_deere": 2800.00,
            "valor_inova": 2520.00
        }
    ]

    exemplo_pesquisa = [
        {
            "numero_peca": "SU300940",
            "data_pesquisa": "2026-05-06",
            "resultados": [
                {"fonte": "EG Peças", "url": "https://egindustriadepecas.com.br", "preco": "R$ 1.200,00", "disponibilidade": "em estoque", "observacao": "preço à vista"},
                {"fonte": "Mercado Livre", "url": "https://mercadolivre.com.br", "preco": "R$ 1.350,00", "disponibilidade": "em estoque", "observacao": ""}
            ],
            "menor_preco_encontrado": "R$ 1.200,00",
            "maior_preco_encontrado": "R$ 1.350,00",
            "media_preco": "R$ 1.275,00"
        }
    ]

    consolidar_planilha(exemplo_banco, exemplo_pesquisa)
